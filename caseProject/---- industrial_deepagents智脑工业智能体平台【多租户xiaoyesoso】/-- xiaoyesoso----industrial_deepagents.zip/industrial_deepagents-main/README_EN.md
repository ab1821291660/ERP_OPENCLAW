# Industrial DeepAgents Platform ("ZhiNao" Industrial Agent Platform)

A multi-tenant industrial agent platform built on [LangChain deepagents](https://docs.langchain.com/oss/python/deepagents), designed for custom (non-standard) order engineering in equipment manufacturing (elevators / lifting systems): natural-language requirements → parameter extraction → design-rule retrieval → sizing & selection → proposal output, with full observability and evaluation.

[中文说明](./README.md)

## Key Features

- **Multi-tenancy & RBAC**: JWT authentication with tenant / project / user isolation and owner / admin / member roles.
- **Projects & conversations**: per-project chat history with SSE streaming (thinking chain / tokens / tool-call events rendered live).
- **deepagents runtime**: virtual filesystem (read / write / edit / glob / grep), sub-agent delegation (`task`), planning (TodoList), and opt-in local sandbox execution (`execute`).
- **Platform skill library (Agent Skills)**: 12 self-contained skills following the official directory conventions (`SKILL.md` + YAML frontmatter + progressive disclosure):
  - `knowledge-search` — knowledge-base retrieval (real seeded data)
  - `web-search` — live web search via DuckDuckGo (free, no API key)
  - `text-file-parser` / `pdf-parser` / `office-parser` / `spreadsheet-parser` / `image-drawing-parser` — per-type file parsing
  - `erp-purchase` / `equipment-logs` / `finance-info` / `drawing-recognition` / `solution-review` — demo data; production use requires customer-system integration
- **File upload**: multipart upload → MinIO object storage (`tenant/project/file/name` keys) with SQLite storing metadata only; size / MIME / extension validation; each type maps to an independent parser skill.
- **Domain toolchain**: design-rule retrieval, shaft-sizing calculator (deterministic rules), process routes, equipment parameters, after-sales policies, calculator, and web search.
- **Evaluation**: LLM-as-judge scoring (per-example assertions + model review) with dataset and run management.
- **Observability**: every run is traced (tool calls, tokens, latency, errors); optional Langfuse integration.
- **Frontend**: single-file React 18 app (no build step), portal + admin modes, streaming Markdown rendering (marked + DOMPurify sanitization).

## Tech Stack

| Layer | Technology |
|---|---|
| Backend | Python 3.12 · FastAPI · SQLite · pydantic-settings |
| Agents | deepagents · langchain-openai (OpenAI-compatible API; Zhipu GLM by default) |
| Object storage | MinIO (`minio` SDK) |
| Web search | DuckDuckGo (`ddgs`, free, no key) |
| Frontend | React 18 UMD · Babel standalone · marked + DOMPurify |
| Observability | Langfuse (optional) |

## Quick Start

### 1. Prerequisites

- Python 3.12+
- Docker (for MinIO)

### 2. Install dependencies

```bash
pip install fastapi "uvicorn[standard]" httpx "python-jose[cryptography]" \
  "passlib[bcrypt]" python-multipart pydantic pydantic-settings python-dotenv \
  pyyaml minio ddgs deepagents langchain-openai langfuse
```

### 3. Configure environment

Create `.env` in the project root (**never commit this file**):

```ini
API_KEY=<your OpenAI-compatible model API key>
BASE_URL=https://open.bigmodel.cn/api/paas/v4/
LLM_MODEL=GLM-5.3-Flash
FLASH_LLM_MODEL=GLM-5.3-Flash
EMBEDDING_MODEL=embedding-3
RERANKER_MODEL=rerank

# MinIO (file upload)
MINIO_ENDPOINT=localhost:9000
MINIO_ACCESS_KEY=minioadmin
MINIO_SECRET_KEY=minioadmin
MINIO_BUCKET=industrial-files

# Optional: Langfuse
# LANGFUSE_PUBLIC_KEY=...
# LANGFUSE_SECRET_KEY=...
# LANGFUSE_HOST=...
```

### 4. Start MinIO (optional; required for file upload)

```bash
docker run -d --name minio-dev -p 9000:9000 -p 9001:9001 \
  -e MINIO_ROOT_USER=minioadmin -e MINIO_ROOT_PASSWORD=minioadmin \
  minio/minio server /data --console-address ':9001'
```

### 5. Run the server

```bash
cd backend
python -m uvicorn app.main:app --host 0.0.0.0 --port 8765
```

Open http://localhost:8765 and sign up (demo account: `demo@local` / `demo1234`).

> The SQLite database and file root live under `backend/data/` (created at runtime, not committed). Without MinIO configured, the upload API returns 503; everything else keeps working.

## Project Layout

```
backend/
├── app/
│   ├── api/            # routers: auth / tenants / agents / tools / threads / evals / traces / industrial
│   ├── services/       # agent_factory / runtime_service / builtin_tools / industrial_tools / minio_service ...
│   ├── repositories/   # SQL access layer
│   ├── config.py       # environment settings
│   ├── db.py           # schema / migrations / seed data
│   └── main.py         # app entry (serves the frontend)
├── skills/             # platform skill library (deepagents Agent Skills)
├── tests/              # pytest (88 tests)
└── data/               # runtime data (not committed)
frontend/
└── index.html          # single-file React app
```

## API Overview (prefix `/api`)

| Module | Sample endpoints | Description |
|---|---|---|
| Auth | `POST /auth/signup` · `POST /auth/login` | Sign up / log in, returns JWT |
| Projects | `GET /projects` | List projects within tenant |
| Threads | `POST /threads` · `POST /threads/{id}/runs` | Create thread; SSE streaming run |
| Files | `POST /industrial/files` · `POST /industrial/files/{id}/parse` | Upload to MinIO; mark parser skill queue |
| Skills | `GET /industrial/skills` | Skill catalog (with wiring status) |
| Tools | `GET /tools` | Platform / sandbox / capability catalog |
| Evals | `POST /evals/runs` | Run evaluation set (LLM judge) |
| Traces | `GET /traces` | Run traces and events |

## Testing

```bash
cd backend && python -m pytest tests/ -q
```

## Known Boundaries (honest disclosure)

- `web-search` uses the free DuckDuckGo backend and returns snippets only (no full-page scraping); on rate limits it degrades gracefully to local-knowledge answers.
- OCR, real CAD drawing parsing, and 3D model parsing are not wired up yet; the related skills explicitly mark these capabilities as unavailable/demo and never fabricate results.
- `erp-purchase` / `equipment-logs` / `finance-info` and similar skills run on demo data; production use requires customer-system integration.

## License

For learning and internal evaluation purposes only.
